<?php
session_start();
$conn=mysqli_connect("localhost","root","12345678","meetingdb");

if(!$conn){
    echo mysqli_connect_errno();
}

?>