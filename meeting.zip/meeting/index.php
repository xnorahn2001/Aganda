<? include("config.php");
$username = $_POST['username'];
$userpassword = $_POST['userpassword'];

if (isset($_POST['b1'])) {
	$result = mysqli_query($conn, "SELECT * FROM  employee WHERE username='$username' and userpassword='$userpassword'");
	if (mysqli_num_rows($result) > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['empId'] = $row["empId"];
		$_SESSION['empName'] = $row["empName"];
		$_SESSION['OK'] = '1';

		echo "<center>  <script> setTimeout(\"location.href='pages/Cpanel.php'\",30);</script>";
	} else {

		$result1 = mysqli_query($conn, "SELECT * FROM `users`  WHERE username='$username' and userpassword='$userpassword'");
		if (mysqli_num_rows($result1) > 0) {
			$row1 = mysqli_fetch_assoc($result1);
			$_SESSION['userid'] = $row1["userid"];
			$_SESSION['OK'] = '1';
			echo "<center>  <script> setTimeout(\"location.href='pages/Cpanel.php'\",30);</script>";
		} else {
			session_destroy();
			echo "<script> alert('تأكد من معلومات الدخول'); window.location.href='singnin.php';</script>";
		}
	}
}


?>
<!DOCTYPE html>
<html lang="zxx">

<head>
	<title>نظام الاجتماعات</title>
	<!-- Meta-Tags -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

	<script type="application/x-javascript">
		addEventListener("load", function() {
			setTimeout(hideURLbar, 0);
		}, false);

		function hideURLbar() {
			window.scrollTo(0, 1);
		}
	</script>
	<!-- //Meta-Tags -->
	<link href="css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /><!--bootstrap-css-->
	<link href="css/font-awesome.css" rel="stylesheet"> <!--font-awesome-css-->
	<link rel="stylesheet" href="css/flexslider.css" type="text/css" media="screen" /><!--flexslider-css-->
	<link href="css/circles.css" rel="stylesheet" type="text/css" media="all" /><!--skill-circles-->
	<link href="css/style.css" rel="stylesheet" type="text/css" media="all" /><!--style-sheet-->
	<link href='css/aos.css' rel='stylesheet prefetch' type="text/css" media="all" /><!--Animation-effects-css-->

	<style>
		html, body{
			background: url(images/services-bg.jpg)repeat 0px 0px;
			background-size: cover;
		}
	</style>
</head>

<body>
	<!--banner start here-->
	
	<div class="header-main">
		<div class="header-top-agileits">
			<div class="container">
				<div class="w3l-social" data-aos="fade-right">
					<ul>
						<li><a href="#"><i class="fa fa-facebook"></i></a></li>
						<li><a href="#"><i class="fa fa-twitter"></i></a></li>
						<li><a href="#"><i class="fa fa-google-plus"></i></a></li>
					</ul>
				</div>

				<div class="clearfix"> </div>
			</div>
		</div>

	</div>


	<div class="container" style="text-align: right;direction: rtl;margin: 11% auto;width: 60%;">
		<div class="panel panel-success">
			<div class="panel-heading">
				<h3 class="panel-title">تسجيل الدخول</h3>
			</div>
			<div class="panel-body">
				<form action="" method="post">
					اسم المستخدم :
					<input type="text" class="form-control" name="username" placeholder="اسم المستخدم" autocomplete="off"><br>
					كلمة المرور :
					<input type="password" class="form-control" name="userpassword" placeholder="كلمة المرور" autocomplete="off"><br>

					<input type="submit" class="btn btn-success" value="دخول" name="b1">
					<input type="reset" class="btn btn-success" value="الغاء الامر">
				</form>

			</div>
		</div>
	</div>
	

	<div class="header-top-agileits" style="width: 100%;position: fixed;bottom: 0;">
		
		<div class="copy">
			<p>© 2023 جميع الحقوق محفوظة لنظام الاجتماعات</p>
		</div>
		
	</div>
	

	<!-- js -->
	<script type="text/javascript" src="js/jquery-2.1.4.min.js"></script>
	<!--search-bar-->
	<script src="js/main.js"></script>
	<!--//search-bar-->
	<!-- FlexSlider -->
	<script defer src="js/jquery.flexslider.js"></script>
	
	<!-- Animation-effect -->
	<script src='js/aos.js'></script>
	<script src="js/aosindex.js"></script>
	<!-- //Animation-effect -->
	<a href="#home" class="scroll" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!-- //smooth scrolling -->
	<script src="js/bootstrap.js"></script>

</body>


</html>