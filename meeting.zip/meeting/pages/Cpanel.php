<? include("../config.php");
if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نظام الاجتماعات</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /><!--bootstrap-css-->
    <link href="../css/font-awesome.css" rel="stylesheet"> <!--font-awesome-css-->
    <link rel="stylesheet" href="../css/flexslider.css" type="text/css" media="screen" /><!--flexslider-css-->
    <link href="../css/circles.css" rel="stylesheet" type="text/css" media="all" /><!--skill-circles-->
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all" /><!--style-sheet-->
    <link href='../css/aos.css' rel='stylesheet prefetch' type="text/css" media="all" /><!--Animation-effects-css-->
<style>
    html, body{
			background: url(images/services-bg.jpg)repeat 0px 0px;
			background-size: cover;
		}
    .a{
        width: 100%;
        height: 40px;
        margin-bottom: 5%;
    }
    .row{
        margin: 2%;
    }
</style>
</head>
<body>
<div class="header-top-agileits">
		   	 <div class="container">
				
				<ul class="agile_forms aos-init aos-animate" data-aos="fade-left">
					<li><a class="active" href="../logout.php"><i class="fa fa-sign-in" aria-hidden="true"></i> Logout</a> </li>
 				</ul>
				<div class="clearfix"> </div>
				</div>
			</div>


    <div class="container-fluid">
        <div class="row">
            <div class="col-md-10">
                <iframe src="" frameborder="0" width="100%" height="500px" name="I1"></iframe>
            </div>
            <div class="col-md-2">
                <?if($_SESSION['userid']){ ?>
                <a href="departmentpage.php" target="I1" class="btn btn-success a">الاقسام</a>
                <a href="employeepage.php" target="I1" class="btn btn-success a">الموظفين</a>
                <a href="taskespage.php" target="I1" class="btn btn-success a">المهام</a>
                <a href="taskFilespage.php" target="I1" class="btn btn-success a">المرفقات</a>
                <a href="adminpage.php" target="I1" class="btn btn-success a">الادارة</a>
                <?}?>
                <?if($_SESSION['empId']){ ?>
                <a href="employeetask.php" target="I1" class="btn btn-success a">مهام الموظف</a>                
                <a href="profile.php" target="I1" class="btn btn-success a">الملف الشخصي</a>
                <?}?>
                
                <a href="../logout.php"  class="btn btn-success a">خروج</a>
            </div>
        </div>
    </div>
    
<!-- contact -->
	<div class="header-top-agileits">
		 
			<!--footer-->
			<div class="copy">
            <p>© 2023 جميع الحقوق محفوظة لنظام الاجتماعات</p>
		    </div>
			<!--/footer -->
		 
	</div>
	<!-- //contact -->
</body>
</html>