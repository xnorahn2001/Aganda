<? include("../config.php");
if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}
$DeptId=$_POST['DeptId'];
$username=$_POST['username'];
$userpassword=$_POST['userpassword'];


if (isset($_POST['b1'])) {
        
        if (mysqli_query($conn, "insert into users(DeptId,username,userpassword) 
        values('$DeptId','$username','$userpassword')")) {

                echo "<script> window.location.href='admin.php';</script>";
        } else {
                echo mysqli_error($conn);
        }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
        <!--script-->
        <script src="../js/jquery-3.3.1.js"></script>
        <!-- js -->
        <script src="../js/bootstrap.js"></script>

</head>

<body>
        <div class="container-fluid " style="text-align: right;direction: rtl;">
                <div class="panel panel-primary">
                        <div class="panel-heading">
                                <h3 class="panel-title">الادارة</h3>
                        </div>
                        <div class="panel-body">
                                <form action="" method="post" enctype="multipart/form-data">
                                        اسم المستخدم :
                                        <input type="text" class="form-control" name="username" placeholder="اسم المستخدم" autocomplete="off"><br>
                                        كلمة المرور :
                                        <input type="text" class="form-control" name="userpassword" placeholder="كلمة المرور" autocomplete="off"><br>
                                       
    القسم :
    <?php
				
                                        $list = mysqli_query($conn, "select * from department");  
                                        echo '<select name="DeptId" class="form-control">';                                    
                                        echo '<option value="">حدد القسم</option>';
                                       
                                        while ($r = mysqli_fetch_assoc($list)) {
                                            echo '<option value="' . $r['DeptId'] . '">' . $r['DeptName'] . '</option>';
                                        }
                                        echo '</select>';
                                    
                                        ?><br>

                                        <input type="submit" class="btn btn-success" value="حفظ" name="b1">
                                        <a href="adminpage.php" class="btn btn-danger">الغاء الامر</a>
                                </form>

                        </div>
                </div>
        </div>

</body>

</html>