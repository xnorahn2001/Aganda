<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
		<!--script-->
		<script src="../js/jquery-3.3.1.js"></script>
		<!-- js -->
		<script src="../js/bootstrap.js"></script>
        <style>
            th,td{
                text-align: center;
            }
        </style>
</head>
<body>
<div class="container" style="direction: rtl;text-align: right;margin: 1% auto 1% auto;">
        <div>
            <a href="admin.php" class="btn btn-success">اضافة جديد</a>
        </div>
        <hr>
        <form action="" method="post" enctype="multipart/form-data">
        <table class="table table-border">
            <tr>
                <th>رقم</th>
                <th>اسم المستخدم</th>
                <th>كلمة المرور </th>
                <th>القسم</th>
                <th>تعديل</th>
                <th>حذف</th>
            </tr>
        
        <?
       include("../config.php");
       if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}
        $sql="select * from users";
        $query=mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($query)){
           echo "
           <tr>
           <td><input type=text name=T1 value='$row[userid]' class=form-control readonly></td>
           <td><input type=text name=T2 value='$row[username]' class=form-control></td>
           <td><input type=text name=T3 value='$row[userpassword]' class=form-control></td> 
           <td><input type=text name=T4 value='$row[DeptId]' class=form-control></td> 
           <td><center><input type=submit name=b1 value=حذف class='btn btn-danger'></td>
           <td><center><input type=submit name=b2 value=تعديل class='btn btn-success'></td>
           </tr>
           "; 
            
           }

           $userid= $_POST['T1'];
           $username= $_POST['T2'];
           $userpassword= $_POST['T3'];
           $DeptId= $_POST['T4'];
           
           if (isset($_POST['b1'])) {
            mysqli_query($conn,"delete from users  where userid='$userid'");
            echo "<script>window.location.href='adminpage.php';</script>";  
           }

           if (isset($_POST['b2'])) {
            mysqli_query($conn,"update users set username='$username',userpassword='$userpassword',DeptId='$DeptId' where userid='$userid'");
            echo "<script>window.location.href='adminpage.php';</script>";  
           }


        ?>
</table>
        </form>
</body>
</html>