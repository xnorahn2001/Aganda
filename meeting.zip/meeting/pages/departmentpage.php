<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
		<!--script-->
		<script src="../js/jquery-3.3.1.js"></script>
		<!-- js -->
		<script src="../js/bootstrap.js"></script>
        <style>
            th{
                text-align: center;
            }
            
            th,td{
                text-align: center;
            }
         
        </style>
</head>
<body>
<div class="container" style="direction: rtl;text-align: right;margin: 1% auto 1% auto;">
        <div>
            <a href="department.php" class="btn btn-success">اضافة جديد</a>
        </div>
        <hr>
        <form action="" method="post" enctype="multipart/form-data">
        <table class="table table-border">
            <tr>
                <th>رقم</th>
                <th>القسم</th>                
                <th>تعديل</th>
                <th>حذف</th>
            </tr>
        
        <?
       include("../config.php");
       if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}

        $sql="select * from department";
        $query=mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($query)){
           echo "
           <tr>
           <td><input type=text name=T1 value='$row[DeptId]' class=form-control readonly></td>
           <td><input type=text name=T2 value='$row[DeptName]' class=form-control autocomplete=off></td>
           <td><center><input type=submit name=b1 value=حذف class='btn btn-danger'></td>
           <td><center><input type=submit name=b2 value=تعديل class='btn btn-primary'></td>
           </tr>
           "; 
            
           }

           $DeptId= $_POST['T1'];
           $DeptName= $_POST['T2'];

           if (isset($_POST['b1'])) {
            mysqli_query($conn,"delete from department  where DeptId='$DeptId'");
            echo "<script>window.location.href='departmentpage.php';</script>";  
           }

           if (isset($_POST['b2'])) {
            if (mysqli_query($conn,"update `department` set DeptName='$DeptName' where DeptId='$DeptId'")){
                echo "<script>window.location.href='departmentpage.php';</script>";  
            }
            else
            {
                echo mysqli_error($conn);
            }
           }


        ?>
</table>
        </form>
</body>
</html>