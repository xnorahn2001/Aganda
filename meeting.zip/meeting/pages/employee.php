<? include("../config.php");
if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}
$DeptId=$_POST['DeptId'];
$empName=$_POST['empName'];
$jobs=$_POST['jobs'];
$username=$_POST['username'];
$userpassword=$_POST['userpassword'];


if (isset($_POST['b1'])) {
        
        if (mysqli_query($conn, "insert into employee(DeptId,empName,jobs,username,userpassword) 
        values('$DeptId','$empName','$jobs','$username','$userpassword')")) {

                echo "<script> window.location.href='employee.php';</script>";
        } else {
                echo mysqli_error($conn);
        }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
		<!--script-->
		<script src="../js/jquery-3.3.1.js"></script>
		<!-- js -->
		<script src="../js/bootstrap.js"></script>
       
</head>

<body>
<div class="container-fluid " style="text-align: right;direction: rtl;">
<div class="panel panel-primary">
  <div class="panel-heading">
    <h3 class="panel-title">الموظفين</h3>
  </div>
  <div class="panel-body">
    <form action="" method="post" enctype="multipart/form-data">    
        اسم الموظف :
    <input type="text" class="form-control" name="empName" placeholder="اسم الموظف" autocomplete="off"><br>
     الوظيفة :
    <input type="text" class="form-control" name="jobs" placeholder="الوظيفة" autocomplete="off"><br>
    
    
    القسم :
    <?php
				
                                        $list = mysqli_query($conn, "select * from department");  
                                        echo '<select name="DeptId" class="form-control">';                                    
                                        echo '<option value="">حدد القسم</option>';
                                       
                                        while ($r = mysqli_fetch_assoc($list)) {
                                            echo '<option value="' . $r['DeptId'] . '">' . $r['DeptName'] . '</option>';
                                        }
                                        echo '</select>';
                                    
                                        ?><br>
اسم المستخدم :
    <input type="text" class="form-control" name="username" placeholder="اسم المستخدم" autocomplete="off"><br>
    كلمة المرور :
    <input type="text" class="form-control" name="userpassword" placeholder="كلمة المرور" autocomplete="off"><br>
    
    
      <input type="submit" class="btn btn-success" value="حفظ" name="b1">
     <a href="employeepage.php" class="btn btn-danger">الغاء الامر</a>
</form>
  
  </div>
</div>
</div>

</body>

</html>