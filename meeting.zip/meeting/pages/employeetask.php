<?
include("../config.php");

if($_SESSION['empId']==''){
	session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}

$empId=$_SESSION['empId'];

$taskes = [];
$result = mysqli_query($conn, "select * from taskes where empId='$empId' and ST=0");
while ($row = mysqli_fetch_assoc($result)) {
    $taskes[]=$row;
}

$mfiles = [];
$result = mysqli_query($conn, "select * from mfile where empId='$empId'");
while ($row = mysqli_fetch_assoc($result)) {
    $mfiles[]=$row;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" media="all" /><!--bootstrap-css-->
    <link href="../css/font-awesome.css" rel="stylesheet"> <!--font-awesome-css-->
    <link rel="stylesheet" href="../css/flexslider.css" type="text/css" media="screen" /><!--flexslider-css-->
    <link href="../css/circles.css" rel="stylesheet" type="text/css" media="all" /><!--skill-circles-->
    <link href="../css/style.css" rel="stylesheet" type="text/css" media="all" /><!--style-sheet-->
    <link href='../css/aos.css' rel='stylesheet prefetch' type="text/css" media="all" /><!--Animation-effects-css-->
    <style>
        p{
            font-size: 1em;
        }
    </style>
</head>
<body>
    <div class="container" style="text-align: right;direction: rtl;">
        <div class="row">
        <div class="col-md-6">
        <div class="panel panel-success">
            <div class="panel-heading">
                <h3 class="panel-title">المرفقات</h3>
            </div>
            <div class="panel-body">
            <? foreach($mfiles as $mfile){?>
                
           
                <a href="<?php echo $mfile['files']; ?>" target="_blank"><i class="fa fa-paperclip fa-1x" aria-hidden="true"></i>
                    <?php echo $mfile['fileTitle']; ?></a>
                    <hr>
                <?}?>

            </div>
        </div>
        </div>
        <div class="col-md-6">
       
            <? foreach($taskes as $taske){?>
                 <div class="panel panel-success">
            <div class="panel-heading">
                <h3 class="panel-title"><?php echo $taske['tasktitle']; ?></h3>

            </div>
            <div class="panel-body">
                
                <p><?php echo $taske['tasktxt']; ?></p><br>
                <p><?php echo $taske['taskdate']; ?></p>
                <form action="" method="post" style="text-align: left;">
                <input type="hidden" name="Id" value="<?php echo $taske['taskid']; ?>">
                    <input type="submit" class="btn btn-success" value="تنفيذ" name="b1">
                </form>
        </div>
        </div>
                <?}?>
           
        </div>
       
        </div>
    </div>
    <?
$taskid=$_POST['Id'];
if (isset($_POST['b1'])) {
    mysqli_query($conn,"update taskes set ST=1 where taskid='$taskid'");
    echo "<script>window.location.href='employeetask.php';</script>";  
   }
    ?>
</body>
</html>