<? include("../config.php");
if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}

$empName=$_POST['empName'];
$jobs=$_POST['jobs'];
$username=$_POST['username'];
$userpassword=$_POST['userpassword'];


$empId=$_SESSION['empId'];


$employees = [];
$result = mysqli_query($conn, "select * from employee where empId='$empId'");
while ($row = mysqli_fetch_assoc($result)) {
    $employees[]=$row;
}

if (isset($_POST['b1'])) {
        
        if (mysqli_query($conn, "UPDATE employee set empName='$empName',jobs='$jobs',username='$username',userpassword='$userpassword' where empId='$empId'")) {

                echo "<script> window.location.href='profile.php';</script>";
        } else {
                echo mysqli_error($conn);
        }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
		<!--script-->
		<script src="../js/jquery-3.3.1.js"></script>
		<!-- js -->
		<script src="../js/bootstrap.js"></script>
       
</head>

<body>
<div class="container-fluid " style="text-align: right;direction: rtl;">
<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">الملف الشخصي</h3>
  </div>
  <div class="panel-body">
    <form action="" method="post" enctype="multipart/form-data">  
    <? foreach($employees as $employee){?>
        <input type="hidden" name="Id" value="<?php echo $employee['empId']; ?>">
        اسم الموظف :
    <input type="text" class="form-control" value="<?php echo $employee['empName']; ?>" name="empName" placeholder="اسم الموظف" autocomplete="off" readonly><br>
     الوظيفة :
    <input type="text" class="form-control" value="<?php echo $employee['jobs']; ?>"  name="jobs" placeholder="الوظيفة" autocomplete="off"><br>
    <br>
اسم المستخدم :
    <input type="text" class="form-control" value="<?php echo $employee['username']; ?>"  name="username" placeholder="اسم المستخدم" autocomplete="off"><br>
    كلمة المرور :
    <input type="text" class="form-control" value="<?php echo $employee['userpassword']; ?>"  name="userpassword" placeholder="كلمة المرور" autocomplete="off"><br>
    
    <?}?>
      <input type="submit" class="btn btn-success" value="حفظ" name="b1">
     
</form>
  
  </div>
</div>
</div>

</body>

</html>