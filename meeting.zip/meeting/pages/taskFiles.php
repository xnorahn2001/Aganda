<? include("../config.php");

if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}


if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}

$empId=$_POST['empId'];
$fileTitle=$_POST['fileTitle'];

$articleImg;

if (isset($_POST['b1'])) {
        $file_name =basename($_FILES['file1']['name']);
	if (move_uploaded_file ( $_FILES["file1"]["tmp_name"] ,"../images/".$file_name )){								
	$articleImg="images/".$file_name; 
    }
        if (mysqli_query($conn, "insert into mfile(empId,fileTitle,files) 
        values('$empId','$fileTitle','$articleImg')")) {

                echo "<script> window.location.href='taskFiles.php';</script>";
        } else {
                echo mysqli_error($conn);
        }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
		<!--script-->
		<script src="../js/jquery-3.3.1.js"></script>
		<!-- js -->
		<script src="../js/bootstrap.js"></script>
   
</head>

<body>
<div class="container-fluid " style="text-align: right;direction: rtl;">
<div class="panel panel-success">
  <div class="panel-heading">
    <h3 class="panel-title">المرفقات</h3>
  </div>
  <div class="panel-body">
    <form action="" method="post" enctype="multipart/form-data">    
        عنوان المرفق :
    <input type="text" class="form-control" name="fileTitle" placeholder="عنوان المرفق " autocomplete="off"><br>
   
    
    اسم الموظف :
                    <?php

                    $list = mysqli_query($conn, "select * from employee");
                    echo '<select name="empId" class="form-control">';
                     echo '<option value="0">حدد الموظف</option>';     

                    while ($r = mysqli_fetch_assoc($list)) {
                        echo '<option value="' . $r['empId'] . '">' . $r['empName'] . '</option>';
                    }
                    echo '</select>';

                    ?><br>
المرفق:
    <input type="file" class="form-control" name="file1"><br>
    
    
      <input type="submit" class="btn btn-success" value="حفظ" name="b1">
     <a href="taskFilespage.php" class="btn btn-danger">الغاء الامر</a>
</form>
  
  </div>
</div>
</div>

</body>

</html>