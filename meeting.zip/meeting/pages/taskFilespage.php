<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
		<!--script-->
		<script src="../js/jquery-3.3.1.js"></script>
		<!-- js -->
		<script src="../js/bootstrap.js"></script>

        <style>
                     
                     th,td{
                         text-align: center;
                     }
                  
                 </style>
</head>
<body>
<div class="container" style="direction: rtl;text-align: right;margin: 1% auto 1% auto;">
        <div>
            <a href="taskFiles.php" class="btn btn-success">اضافة جديد</a>
        </div>
        <hr>
        <form action="" method="post" enctype="multipart/form-data">
        <table class="table table-border">
            <tr>
                <th>رقم</th>
               <th>الموظف</th>
               <th>المرفق</th>
              
                
                <th>تعديل</th>
                <th>حذف</th>
            </tr>
        
        <?
       include("../config.php");
       if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}


        $sql="select * from mfile";
        $query=mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($query)){
           echo "
           <tr>
           <td><input type=text name=T1 value='$row[fileId]' class=form-control readonly></td>
           <td><input type=text name=T2 value='$row[empId]' class=form-control></td>
           <td><input type=text name=T3 value='$row[fileTitle]' class=form-control></td>      
          
           <td><center><input type=submit name=b1 value=حذف class='btn btn-danger'></td>
           </tr>
           "; 
            
           }

           $fileId= $_POST['T1'];
           
           if (isset($_POST['b1'])) {
            mysqli_query($conn,"delete from mfile  where fileId='$fileId'");
            echo "<script>window.location.href='taskFilespage.php';</script>";  
           }

           


        ?>
</table>
        </form>
</body>
</html>