<? include("../config.php");
if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}
$empId=$_POST['empId'];
$tasktitle=$_POST['tasktitle'];
$tasktxt=$_POST['tasktxt'];


if (isset($_POST['b1'])) {
        
        if (mysqli_query($conn, "insert into taskes(empId,tasktitle,tasktxt,taskdate,ST) 
        values('$empId','$tasktitle','$tasktxt',now(),0)")) {

                echo "<script> window.location.href='taskes.php';</script>";
        } else {
                echo mysqli_error($conn);
        }
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
    <!--script-->
    <script src="../js/jquery-3.3.1.js"></script>
    <!-- js -->
    <script src="../js/bootstrap.js"></script>

</head>

<body>
    <div class="container-fluid " style="text-align: right;direction: rtl;">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <h3 class="panel-title">المهام</h3>
            </div>
            <div class="panel-body">
                <form action="" method="post" enctype="multipart/form-data">

                    اسم الموظف :
                    <?php

                    $list = mysqli_query($conn, "select * from employee");
                    echo '<select name="empId" class="form-control">';
                     echo '<option value="0">حدد الموظف</option>';     

                    while ($r = mysqli_fetch_assoc($list)) {
                        echo '<option value="' . $r['empId'] . '">' . $r['empName'] . '</option>';
                    }
                    echo '</select>';

                    ?><br>
                    عنوان المهمة :
                    <input type="text" class="form-control" name="tasktitle" placeholder=" عنوان المهمة " autocomplete="off"><br>

                    المهمة :
                    <textarea name="tasktxt" id="" cols="30" rows="10" class="form-control"></textarea>

                    <br><input type="submit" class="btn btn-success" value="حفظ" name="b1">
                    <a href="taskespage.php" class="btn btn-danger">الغاء الامر</a>
                </form>

            </div>
        </div>
    </div>

</body>

</html>