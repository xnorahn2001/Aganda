<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
    <link href="../css/bootstrap.css" rel="stylesheet" type="text/css" />
		<!--script-->
		<script src="../js/jquery-3.3.1.js"></script>
		<!-- js -->
		<script src="../js/bootstrap.js"></script>
        <style>
            th,td{
                text-align: center;
            }
        </style>
</head>
<body>
<div class="container" style="direction: rtl;text-align: right;margin: 1% auto 1% auto;">
        <div>
            <a href="taskes.php" class="btn btn-success">اضافة جديد</a>
        </div>
        <hr>
        <form action="" method="post" enctype="multipart/form-data">
        <table class="table table-border">
            <tr>
                <th>رقم</th>
               <th>الموظف</th>
               <th>عنوان المهمة</th>
               <th>المهمة </th>
               <th>التاريخ </th>
                
                <th>تعديل</th>
                <th>حذف</th>
            </tr>
        
        <?
       include("../config.php");
       if($_SESSION['OK']=='')
{
    session_destroy();
echo "<script>window.location.href='../index.php';</script>";  
}

        $sql="select * from taskes";
        $query=mysqli_query($conn,$sql);
        while($row = mysqli_fetch_assoc($query)){
           echo "
           <tr>
           <td><input type=text name=T1 value='$row[taskid]' class=form-control readonly></td>
           <td><input type=text name=T2 value='$row[empId]' class=form-control></td>
           <td><input type=text name=T3 value='$row[tasktitle]' class=form-control></td>      
           <td><input type=text name=T4 value='$row[tasktxt]' class=form-control></td> 
           <td><input type=text name=T5 value='$row[taskdate]' class=form-control></td> 
           
           <td><center><input type=submit name=b1 value=حذف class='btn btn-danger'></td>
           <td><center><input type=submit name=b2 value=تعديل class='btn btn-primary'></td>
           </tr>
           "; 
            
           }

           $taskid= $_POST['T1'];
           $empId= $_POST['T2'];
           $tasktitle= $_POST['T3'];
           $tasktxt= $_POST['T4'];

           if (isset($_POST['b1'])) {
            mysqli_query($conn,"delete from taskes  where taskid='$taskid'");
            echo "<script>window.location.href='taskespage.php';</script>";  
           }

           if (isset($_POST['b2'])) {
            mysqli_query($conn,"update taskes set taskdate=now(),empId='$empId',tasktitle='$tasktitle',tasktxt='$tasktxt' where taskid='$taskid'");
            echo "<script>window.location.href='taskespage.php';</script>";  
           }


        ?>
</table>
        </form>
</body>
</html>