<? include("header.php");
$username = $_POST['username'];
$userpassword = $_POST['userpassword'];

if (isset($_POST['b1'])) {
  $result = mysqli_query($conn, "SELECT * FROM  members WHERE username='$username' and userpassword='$userpassword'");
  if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $_SESSION['memberId'] = $row["memberId"];
    $_SESSION['memberName'] = $row["memberName"];

    echo "<center>  <script> setTimeout(\"location.href='index.php'\",30);</script>";
  } else {

    $result1 = mysqli_query($conn, "SELECT * FROM `users`  WHERE username='$username' and userpassword='$userpassword'");
    if (mysqli_num_rows($result1) > 0) {
      $row1 = mysqli_fetch_assoc($result1);
      $_SESSION['userid'] = $row1["userid"];
      echo "<center>  <script> setTimeout(\"location.href='pages/Cpanel.php'\",30);</script>";
    } else {
      session_destroy();
      echo "<script> alert('تأكد من معلومات الدخول'); window.location.href='singnin.php';</script>";
    }
  }
}


?>

<div class="container" style="text-align: right;direction: rtl;">
  <div class="panel panel-primary">
    <div class="panel-heading">
      <h3 class="panel-title">تسجيل الدخول</h3>
    </div>
    <div class="panel-body">
      <form action="" method="post">
        اسم المستخدم :
        <input type="text" class="form-control" name="username" placeholder="اسم المستخدم" autocomplete="off"><br>
        كلمة المرور :
        <input type="password" class="form-control" name="userpassword" placeholder="كلمة المرور" autocomplete="off"><br>

        <input type="submit" class="btn btn-success" value="دخول" name="b1">
        <input type="reset" class="btn btn-success" value="الغاء الامر">
      </form>

    </div>
  </div>
</div>
<? include("footer.php"); ?>